package com.Proyecto.ProyectoProgra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoPrograApplicationTests {

	@Test
	void contextLoads() {
	}

}
