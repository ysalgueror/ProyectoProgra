package com.Proyecto.ProyectoProgra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoPrograApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoPrograApplication.class, args);
	}

}
