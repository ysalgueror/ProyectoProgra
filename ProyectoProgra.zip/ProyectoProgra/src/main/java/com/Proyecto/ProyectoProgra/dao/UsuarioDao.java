package com.Proyecto.ProyectoProgra.dao;


import com.Proyecto.ProyectoProgra.models.Usuario;
import java.util.List;

public interface UsuarioDao {
    List<Usuario> getUsuarios ();


}
